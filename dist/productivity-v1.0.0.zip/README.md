# Productivity Skill Pack

This pack bundles documentation and SOP automation skills.

## Install

```bash
# Install all free skills
npx returnmytime add skill ReturnMyTime/skills
```

## Build Pack Zip

```bash
./scripts/build-pack.sh productivity
```
