# Development Skill Pack

This pack bundles planning and repo analysis skills for coding agents.

## Install

```bash
# Install all free skills
npx returnmytime add skill ReturnMyTime/skills
```

## Build Pack Zip

```bash
./scripts/build-pack.sh development
```
